package com.training.DemoJenkins.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JenkinsController {
	
	@GetMapping("/getMsg")
	public String sendMessage()
	{
		return "Hello from demo jenkins deployer";
	}

}
