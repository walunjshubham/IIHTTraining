package com.training.kafkaconsumer.model;

import org.springframework.stereotype.Component;

@Component
public class User1
{
	private String name;
	private String department;
	private long salary;
	
	public User1() {
		// TODO Auto-generated constructor stub
	}
	public User1(String name,String dept,long salary) {
		// TODO Auto-generated constructor stub
		this.name=name;
		this.department=dept;
		this.salary=salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "User [name=" + name + ", department=" + department + ", salary=" + salary + "]";
	}
	
	
}
