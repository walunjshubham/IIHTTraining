package com.training.kafkaconsumer.listner;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.training.kafkaconsumer.model.User1;

@Service
public class KafkaConsumer {

	@KafkaListener(topics = "demo_topic" ,groupId="group_json",
			containerFactory="userKafkaListnetFactory")
	public void consume(User1 user)
	{
		System.out.println("Consumed msg"+user);
	}
}
