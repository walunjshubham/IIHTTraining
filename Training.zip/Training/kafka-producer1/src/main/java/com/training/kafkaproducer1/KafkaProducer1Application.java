package com.training.kafkaproducer1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaProducer1Application {

	public static void main(String[] args) {
		SpringApplication.run(KafkaProducer1Application.class, args);
	}

}
