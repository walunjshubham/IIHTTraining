package com.training.kafkaproducer1.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.training.kafkaproducer1.model.User1;

@RestController
@RequestMapping
public class UserController
{
	@Autowired 
	private KafkaTemplate<String , User1> kafkTemp;
	
	
	//create topic 
	
	private static final String TOPIC="demo_topic";
	
	@GetMapping("/publish/{name}")
	public String publish(@PathVariable ("name") String name)
	{
		kafkTemp.send(TOPIC,new User1(name,"sales",3000) );
		return "published message";
	}
	
	
	
}
