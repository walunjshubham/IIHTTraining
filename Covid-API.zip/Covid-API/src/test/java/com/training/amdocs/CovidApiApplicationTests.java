package com.training.amdocs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CovidApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
